
function myfunction(){

    
    var x = document.getElementById("first");
    if (x.style.display === "block") {
      x.style.display = "none";
    } else {
      x.style.display = "block";
    }




}


function myfunction1(){

    var y = document.getElementById("second");
    if (y.style.display === "block") {
      y.style.display = "none";
    } else {
      y.style.display = "block";
    }


}


function myfunction2(){

    var z = document.getElementById("third");
    if (z.style.display === "block") {
      z.style.display = "none";
    } else {
      z.style.display = "block";
    }


}




function myfunction3(){

    var z = document.getElementById("four");
    if (z.style.display === "block") {
      z.style.display = "none";
    } else {
      z.style.display = "block";
    }


}


